//Hw 5

package interface1;

public interface LoanConstants
{
 final int sTerm = 1;
 final int mTerm = 3;
 final int lTerm = 5;
 
 final String name = "Company Name";
 final double maxAmt = 100000.00;
}
