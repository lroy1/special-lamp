//hw 5

package superclass;
import interface1.LoanConstants;

public abstract class Loan implements LoanConstants
{
 private int id;
 private String lastName;
 private double amt;
 private double rate;
 private int term;
 private static int idCounter =1;
 
 private final double maxAmt = 100000.00;
 
 public Loan(){
  this.setLastName(" ");
  this.setTerm(0);
  this.setAmount(0.00);
  this.id=idCounter++;
 }
 
 public Loan( String lname, int term1, double amount){
  this.setLastName(lname);
  this.setTerm(term1);
  this.setAmount(amount);
  this.id=idCounter++;
 }
 
 public double getRate(){
  return this.rate;
 }
 public int getID(){
  return this.id;
 }
 
 public String getLastName(){
  return this.lastName;
 }
 
 public int getTerm(){
  return this.term;
 }
 
 public double getAmount(){
  return this.amt;
 }
 
 public void setLastName( String name){
  this.lastName = name;
 }
 
 public void setAmount( double amt1){
  if ( amt1 < maxAmt && amt1 >0.00){
  this.amt= amt1;}
  else { System.out.println("invalid input for amount");
  this.setAmount(0.00);}
 }
 
 public void setTerm( int term2){
  if ( term2 == sTerm){
   this.term=term2;}
  else if (term2== mTerm){
  this.term=term2;}
  else if (term2== lTerm){
  this.term=term2;}
   else { System.out.println("invalid input for term");
  this.setTerm(1);}
 }
 
 public void setRate(double ratePassed){
   this.rate=ratePassed;
  }
  
 public double paymentDue(){
 }
 
 public String toString(){
  return "customer last name: "+getLastName()+" loan amount: "+getAmount()+" term of loan: "+getTerm();
 }
}
 
 