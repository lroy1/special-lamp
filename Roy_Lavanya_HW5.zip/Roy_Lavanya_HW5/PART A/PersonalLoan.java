//hw 5

package subclass;
import superclass.Loan;
import interface1.LoanConstants;
import subclass.BusinessLoan;

public class PersonalLoan extends Loan
{
 private final double additional=2 ;
 
 public PersonalLoan(){
  super();
  super.setRate(0+ additional);
 }
 
 public PersonalLoan(String lastName,  int term, double amt, double interest){
  super(lastName, term, amt);
  super.setRate(interest+additional);
 }
 
 public double paymentDue(){
	 double rate = super.getRate();
	 double amt= super.getAmount();
     double product = rate*amt;
     double ret = amt+ product;
  return ret;	 
 }

 public String toString(){
	 return super.toString()+ "amount due at end of term: "+paymentDue();
 }
}
