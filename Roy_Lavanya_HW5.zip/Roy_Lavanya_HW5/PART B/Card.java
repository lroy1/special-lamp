//hw 5
//package service;
public class Card
{
 private String suit;
 private String value;
 
 public Card(){
  this.setSuit(null);
  this.setValue(null);
 }
 
 public Card( String suit1, String val){
  this.setSuit(suit1);
  this.setValue(val);
 }
 
 public String getSuit(){
  return this.suit;
 }
 
 public String getValue(){
  return this.value;
 }
 
 public void setSuit( String suits){
  this.suit= suits;
 }
 
 public void setValue(String vals){
  this.value=vals;
 }
 
}