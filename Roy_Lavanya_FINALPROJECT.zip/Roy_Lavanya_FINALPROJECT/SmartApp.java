//Project

package subclass;
import superclass.Appliance;

public class SmartApp extends Appliance
{
 private double probLow;
 
 public SmartApp(){
  super();
  probLow=0.0;
 }
 
 public SmartApp(String name, int loc, int on, double probOn, double probL){
  super(name, loc, on, probOn);
  this.setProbLow(probL);
 }
 

 public double getProbLow(){
  return this.probLow;
 }
 
 public void setProbLow(double l){
  this.probLow=l;
 }
 
 public int FindLowWatt(){
   double red = this.getProbLow();
   int watt = this.getOnWattage();
   int pro = (int)red*watt;
   return pro;
 }
 
 public String toString(){
  return super.toString()+" appliance of type: Smart, probability of being on low: "+getProbLow();
 }
}