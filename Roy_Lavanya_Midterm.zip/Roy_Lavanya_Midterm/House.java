// midterm part A 
package Midterm.Service;

public class House 
{
 private String name;
 private double men;
 private double women;
 
 public House()
 {
  this.setName(" ");
  this.setMen(0);
  this.setWomen(0);
 }
 
 public House(String hName, double men1, double women1)
 {
  this.setName(hName);
  this.setMen(men1);
  this.setWomen(women1);
 }
 
 public String getName()
 {
 return this.name;
 }
 public double getMen()
 {
  return this.men;
 }
 
 public double getWomen()
 {
  return this.women;
 }
 
 public void setName(String name1)
 {
  this.name=name1;
 }
 
 public void setMen(double men2)
 {
  this.men=men2;
 }
 
 public void setWomen(double women2)
 {
  this.women=women2;
 }
 
 public String toString()
 {
  return "the name of the house is: "+this.getName()+"the number of men in the house is: "+this.getMen()+"the number of women in this house is: "+this.getWomen()+"the ratio of men to women in this house is: "+this.ratioMaleFemale();
 }
 
 public double ratioMaleFemale()
 {
	 double c=0.00;
	double a=this.getMen();
	double b=this.getWomen();
	if (b==0.00)
	{ 
     c=a;
	}
	else{ c=a/b;}
	

  
  return c;
 }
 
}