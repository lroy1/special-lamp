// QUIZ 2 

package superclass;
import interface1.ChargeConstants;

public abstract class Package implements ChargeConstants
{
 private String fromAddress;
 private String toAddress;
 private float weight;
 private int packageID;
 
 private static int idcounter=10000;
 
 public Package(){
  this.setFromAddress(" ");
  this.setToAddress(" ");
  this.setWeight(0.0f);
  this.idcounter++;
  this.setID(idcounter);
 }
 
 public Package(String f, String t, float w){
  this.setFromAddress(f);
  this.setToAddress(t);
  this.setWeight(w);
  this.idcounter++;
  this.setID(idcounter);
 }
 
 public int getID(){
  return this.packageID;
 }
 
 public String getFromAddress(){
  return this.fromAddress;
 }
 
 public String getToAddress(){
  return this.toAddress;
 }
 
 public float getWeight(){
  return this.weight;
 }
 
 public void setID(int num){
  this.packageID=num;
 }
 
 public void setFromAddress(String add){
  this.fromAddress=add;
 }
 
 
 public void setWeight(float we){
  this.weight=we;
 }
 
 public void setToAddress(String tAdd){
  this.toAddress=tAdd;
 }
 
 public float CalculateCharge() {
	 return 0.0f;
 }
 
 public abstract String printReceipt();
}

  
  
  
  