//QUIZ 2

package subclass;
import superclass.Package;
import interface1.ChargeConstants;

public class OverNightPackage extends Package implements ChargeConstants
{
 
 public OverNightPackage(String fAdd, String tAdd, float weight){
  super(fAdd, tAdd, weight);
 }
 
 public float CalculateCharge(){
  float a= baseCharge;
  float pro= a*(this.getWeight());
  float extra= overNightExtraCharge;
  float pro2= extra*(this.getWeight());
  float ret= pro+pro2;
  return ret;
 }
 
 public String printReceipt(){
  return "Receipt of package ID: "+this.getID()+" this is package of type: overnight package, from: "+this.getFromAddress()+" to: "+this.getToAddress()+" weight: "+this.getWeight()+"oz, total cost of package: $"+this.CalculateCharge();
 }
}