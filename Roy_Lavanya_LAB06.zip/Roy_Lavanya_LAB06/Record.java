package superclass;

public class Record
{
 private String title;
 private String PDate;
 //private String editor;
  private static int counter=10000;//static variable
  public String ID;
 
 public Record(){
 this.setTitle(" ");
 this.setDate(" ");
 //this.setEditor(" ");
  this.ID=""+this.counter;
  this.counter++;
 }
 
 public Record( String title1, String date){
  this.setTitle(title1);
  this.setDate(date);
  //this.setEditor(edit);
    this.ID=""+this.counter;
	   this.counter++;
  }
 
 //accessor 
 
 public String getTitle(){
  return this.title;
  }
  
 public String getDate(){
  return this.PDate;
 }
 
 //public String getEditor(){
  //return this.editor;
 
 
 //mutator 
 
 public void setTitle( String title2){
  this.title=title2;
 }
 
 public void setDate( String date1){
  this.PDate= date1;
 }
 
 /*public void setEditor( String author){
  this.editor=author;
 }*/
 
 public String toString(){
  return "the Title is: "+getTitle()+" the date of publishing is: "+getDate();
 }
 
}
 