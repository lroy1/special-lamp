//lab 08

package client;
import superclass.GeometricFigure;
import subclass.Square;
import subclass.Triangle;

public class UseGeometric
{
 public static void main(String args [])
 {
  Square s1 = new Square(2.3, 2.3);
  Square s2 = new Square(3.4, 3.4);
  Square s3 = new Square(4.5, 4.5);
  Square s4 = new Square(5.6, 5.6);
  Square s5 = new Square(6.6, 6.6);
  
  Triangle t1= new Triangle( 2.1, 3.2);
  Triangle t2= new Triangle( 4.5, 3.2);
  Triangle t3= new Triangle( 2.1, 6.2);
  Triangle t4= new Triangle( 5.4, 7.3);
  Triangle t5= new Triangle( 3.3, 8.2);
  
  GeometricFigure g1 [] = {s1, s2, s3, s4, s5, t1, t2, t3, t4, t5};
  
  for (int i=0; i<10; i++){
   System.out.println(g1[i].toString());
  }
 }
}