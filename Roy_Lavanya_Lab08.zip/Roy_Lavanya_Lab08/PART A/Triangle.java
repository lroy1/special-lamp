//lab 08

package subclass;
import superclass.GeometricFigure;
import subclass.Square;

public class Triangle extends GeometricFigure
{
 
 public Triangle(){
  super();
 }
 
 public Triangle(double height, double width){
  super(height, width);
 }
 
 public double area(){
  double a=this.getHeight();
  double b=this.getWidth();
  double ret= 0.5*a*b;
  return ret;
 }
 
 public String toString(){
  return super.toString()+" area of figure: "+this.area();
 }
}