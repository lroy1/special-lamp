package subclass;
import superclass.GeometricFigure2;
import subclass.Square2;
import interface1.SidedObject;

public class Triangle2 extends GeometricFigure2 //implements SidedObject
{
 
 public Triangle2(){
  super();
 }
 
 public Triangle2(double height, double width){
  super(height, width);
 }
 
 public double area(){
  double a=this.getHeight();
  double b=this.getWidth();
  double ret= 0.5*a*b;
  return ret;
 }
 
 public int displaySides(){
 double h= this.getHeight();
  double w= this.getWidth();
  if(h==w){
   System.out.println("this geometric figure is of type Square");
   return 4;}
  else { System.out.println("this geometric figure is of type Triangle");
   return 3;}
 }
 
 public String toString(){
  return super.toString()+" area of figure: "+this.area()+"the number of sides: "+this.displaySides();
 }
}