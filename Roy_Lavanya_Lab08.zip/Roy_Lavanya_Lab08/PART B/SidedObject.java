//lab 08 part B 

package interface1;
import superclass.GeometricFigure2;

public interface SidedObject
{
 public int displaySides();
 /* double h= g.getHeight();
  double w= g.getWidth();
  if(h==w){
   System.out.println("this geometric figure is of type Square");
   return 4;}
  else { System.out.pritnln("this geometric figure is of type Triangle");
   return 3;}
 }*/
}
  