// client class part A
package Midterm.client;
import Midterm.Service.Quad;
import Midterm.Service.House;
import java.util.*;
import java.io.*;

public class QuadClient{

   
  
    public boolean duplicate( House []  h2)
	{
	 for(int i=0; i<h2.length; i++){
	  for(int j=1; j<i; j++){
	  if(h2[i].getName()==h2[j].getName())
	  { 
	   System.out.println("duplicate found");
	  double a= h2[i].getMen() + h2[j].getMen();
	  h2[i].setMen(a);
	   double b =h2[i].getWomen() + h2[j].getWomen();
	   h2[i].setWomen(b);
	  }
	 }
	}
	System.out.println("adjusted the number of men and women");
	return true;
	}
	
	public House [] sortRatio(House [] h3)
	{
	 System.out.println("sorting in decreasing order male to female ratio");
	 House temp;
	 int subarray=0;
	 int index=0;
	 
	 for(int j=0; j<h3.length; j++)
	 {
	  subarray=h3.length-j;
	  index=0;
	  for(int k=1; k<subarray; k++)
	  {
	   if(h3[k].ratioMaleFemale()>h3[index].ratioMaleFemale())
	     index=k;
	  }
	  temp=h3[index];
	  h3[index]=h3[h3.length-1];
	  h3[h3.length-1]=temp;
	 }
	 return h3;
	}
	 
	
	public static void main(String args[]){
		QuadClient lib= new QuadClient();
		String line = new String();
		String name=" ";
		double men=0.00;
		double women=0.00;
		House h1;
		House [] houses;
		int counter=0;
		
		try{
			File textFile = new File("HouseTxt.txt");
			Scanner scan = new Scanner(textFile);
			
			
			while(scan.hasNextLine())
			{
				line=scan.nextLine();				
				counter++;
			}
			scan.close();
			System.out.println("the num of lines are: "+counter);
			System.out.println("creating objects");
			
			houses=new House [counter];
			String read=" ";
			scan=new Scanner(textFile);
			for(int i=0; i<counter; i++)
			{
			 read=scan.nextLine();
			 String [] tok=read.split(":");
			 name=tok[0];
			 men=Double.parseDouble(tok[1]);
			 women=Double.parseDouble(tok[2]);
			 
			 h1=new House(name, men, women);
			 houses[i]=h1;
			}
			 
			boolean checkDuplicate=lib.duplicate(houses);
			houses= lib.sortRatio(houses);
			
			for(int z=0; z<counter; z++)
			{
			 System.out.println(houses[z].toString());
			}
			
		}catch(IOException e){
			System.out.println("Issues with reading the file. Aborting");
			System.out.println(e.getMessage());
		}
	}	
}