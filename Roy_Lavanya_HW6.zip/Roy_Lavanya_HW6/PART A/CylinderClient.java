// HW 6

package client;
import superclass.Circle;
import subclass.Cylinder;

public class CylinderClient
{
 public static void main(String args [])
 {
  Circle c1= new Circle (5);
  System.out.println(c1.toString());
  
  Cylinder cl1 = new Cylinder (3, 4);
  System.out.println(cl1.toString());
  
  Cylinder cl2= new Cylinder (c1, 6);
  System.out.println(cl2.toString());
  
  c1.setRadius (6);
  System.out.println(c1.toString());
  
  System.out.println(cl1.getRadius());
  System.out.println(cl2.area());
 }
}