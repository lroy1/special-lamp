//hw 5

package client;
import superclass.Loan;
import interface1.LoanConstants;
import subclass.BusinessLoan;
import subclass.PersonalLoan;
import java.util.*;


public class CreateLoans
{
 public static void main(String args [])
 {
  Loan [] loans= new Loan[5];
  double interest=0;
  String lastName;
  String type;
  double amt;
  int term;
  
  Scanner scan = new Scanner(System.in);
  boolean input = true;
 
  
  while(input)
  { 
   System.out.println("enter prime interest rate");
   interest=scan.nextDouble();
   
   if (interest<0) {System.out.println("invalid input");};
  input= false;
  }
  
  
   for(int i=0; i<loans.length; i++)
   {
	  System.out.println("enter type of loan: Business or Personal");
	  type = scan.next();
	  System.out.println("enter last name");
	  scan.nextLine();
	  lastName= scan.nextLine(); //System.out.println("hey"+lastName); //testcase
	  System.out.println("enter amount of the loan");
	  amt = scan.nextDouble();
	  System.out.println("enter term of loan");
	  term= scan.nextInt();
	 
	 if ( type.equalsIgnoreCase("personal"))
	  { //System.out.println("type of loan selected: personal"); //testcase
	   PersonalLoan pLoan = new PersonalLoan(lastName, term, amt, interest);
	   loans[i]=pLoan;
	   
	  }
	 else if(type.equalsIgnoreCase("business"))
	  { //System.out.println("type of loan selected: business"); //testcase
	   BusinessLoan bLoan= new BusinessLoan(lastName, term, amt, interest);
	   loans[i]=bLoan;
	  
	  }
     else { System.out.println("invalid loan type");
	
	}
  }
  
  for(int j=0; j<loans.length; j++){
   System.out.println(loans[j].toString());
  }
 }
}
	 