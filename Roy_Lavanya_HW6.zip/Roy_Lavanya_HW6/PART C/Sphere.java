// HW 6

package subclass;
import superclass.CircleVolume;

public class Sphere extends CircleVolume
{
 
 public Sphere(){
  super();
 }
 
 public Sphere( double radius){
  super(radius);
 }
 
 public Sphere(CircleVolume c1){
  super(c1.getRadius());
 }
 
 public double volume(){
  double r= this.getRadius();
  double pro= 4*3.14*r*r*r;
  System.out.println("formula is: 4/3 pi r^3");
  double ret= pro/3;
  return ret;
 }
 
 public String toString(){
  return super.toString()+" the volume of sphere is: "+volume();
 }
}