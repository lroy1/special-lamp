//HW 6

package subclass;
import superclass.Circle;

public class Cylinder extends Circle
{
 private float height;
 
 public Cylinder(){
  super();
  height= 0.0f;
  height= 0.0f;
 }
 
 public Cylinder(double r, float h){
  super(r);
  this.setHeight(h);
 }
 
 public Cylinder(Circle c, float hgt){
  super(c.getRadius());
  this.setHeight(hgt);
 }
 
 public float getHeight(){
  return this.height;
 }
 
 public void setHeight(float h){
  this.height=h;
 }
 
 public double volume(){
  float h= this.getHeight();
  double area= this.area();
  double ret= area*h;
  return ret;
 }
 
 public String toString(){
  return super.toString()+" the height of cylinder is: "+this.getHeight()+" the volume of cylinder is: "+volume();
 }
}