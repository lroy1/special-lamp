//HW6 

package client;
import superclass.CircleVolume;
import subclass.Sphere;
import subclass.Cylinder;

public class CylinderSphereClient
{
 public static void main(String args [])
 {
  Cylinder cl1=new Cylinder( 28, 35);
  System.out.println(cl1.toString());
  
  Sphere s1= new Sphere(6);
  System.out.println(s1.toString());
  
  CircleVolume cv1;
  cv1 = cl1;
  System.out.println(cv1.area());
  System.out.println(cv1.circumference());
  System.out.println(cv1.volume());
  
  cv1= s1;
  System.out.println(cv1.area());
  System.out.println(cv1.circumference());
  System.out.println(cv1.volume());
  
  CircleVolume cv [] = new CircleVolume[4];
  Sphere sphere2 = new Sphere(20);
  cv[0] = sphere2;
  Sphere sphere3 = new Sphere(25);
  cv[1] = sphere3;
  Cylinder cylinder2 = new Cylinder(3, 4);
  cv[2] = cylinder2;
  Cylinder cylinder3 = new Cylinder(4, 3);
  cv[3] = cylinder3;
  
  for(int i=0; i<4; i++){
   System.out.println(cv[i].toString());
  }
	
  
 }
}