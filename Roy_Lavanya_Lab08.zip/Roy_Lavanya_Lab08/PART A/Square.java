// lab 08

package subclass;
import superclass.GeometricFigure;

public class Square extends GeometricFigure
{
 
 public Square(){
  super();
 }
 
 public Square( double h, double w){
  super(h,w);
 }

 
 public double area(){
  double a= this.getHeight();
  double b= this.getWidth();
  double ret= a*b;
  return ret;
 }
 
 public String toString(){
  return super.toString()+" area of figure is: "+this.area();
 }
}