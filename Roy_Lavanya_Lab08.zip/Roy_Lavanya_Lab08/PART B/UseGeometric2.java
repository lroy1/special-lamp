package client;
import superclass.GeometricFigure2;
import subclass.Square2;
import subclass.Triangle2;
import interface1.SidedObject;

public class UseGeometric2
{
 public static void main(String args [])
 {
  Square2 s1 = new Square2(2.3, 2.3);
  Square2 s2 = new Square2(3.4, 3.4);
  Square2 s3 = new Square2(4.5, 4.5);
  Square2 s4 = new Square2(5.6, 5.6);
  Square2 s5 = new Square2(6.6, 6.6);
  
  Triangle2 t1= new Triangle2( 2.1, 3.2);
  Triangle2 t2= new Triangle2( 4.5, 3.2);
  Triangle2 t3= new Triangle2( 2.1, 6.2);
  Triangle2 t4= new Triangle2( 5.4, 7.3);
  Triangle2 t5= new Triangle2( 3.3, 8.2);
  
  GeometricFigure2 g1 [] = {s1, s2, s3, s4, s5, t1, t2, t3, t4, t5};
  
  for (int i=0; i<10; i++){
   System.out.println(g1[i].toString());
  }
 }
}