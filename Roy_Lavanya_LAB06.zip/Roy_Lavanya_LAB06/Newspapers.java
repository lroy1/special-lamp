package subclasses;
import superclass.Record;

public class Newspapers extends Record
{
 private String edition;
 private String editor;
 
 
 public Newspapers(){
  this.setEdition(" ");
  this.setEditor(" ");
  
 }
 
 public Newspapers( String edi, String edit){
  this.setEdition(edi);
  this.setEditor(edit);
 }
 
 public Newspapers ( String title, String date, String edition1, String editor){
  super( title, date);
  this.setEdition(edition1);
  this.setEditor(editor);
 }
 
 public void setEditor( String author){
  this.editor=author;
 }
 
 public String getEdition(){
  return this.edition;
 }
 
 public String getEditor(){
 return this.editor;}
 
 
 public void setEdition( String edi1){
  this.edition= edi1;
 }
 
 public String toString(){
  return super.toString()+" the newspaper has the edition "+getEdition()+" the name of editor is: "+getEditor();
 }
 
}
