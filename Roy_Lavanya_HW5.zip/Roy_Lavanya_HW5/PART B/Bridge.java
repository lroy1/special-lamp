//hw 5
/*package subclass;

import service.Card;
import superclass.CardGame;*/
import java.util.*;

public class Bridge implements CardGame
{
 private static final int DEALS =13;
 Vector<Card> dealer = super.getDeck();
 
 public Bridge(){
  super(DEALS);
 }
 
 public String displayDescription(){
  return "According to Wikipedia, \"Contract bridge, or simply bridge, is a trick-taking game using a standard 52-card deck.\n" +
				"It is played by four players in two competing partnerships, with partners sitting opposite each other around a table.\n" +
				"Millions of people play bridge worldwide in clubs, tournaments, online and with friends at home, making it one of the \n" +
				"world's most popular card games, particularly among seniors. The World Bridge Federation is the governing body for \n" +
				"international competitive bridge.\"";
	}
  
  public String Deal(){
   String hand;
   int size= this.dealer.size();
    super.shuffle(this.dealer, this.dealer.size());
			hand = "";
			int start = this.dealer.size() - 1;
			int end = start - DEALS;
			for (int i = start; i > end; i--)
			{
				String s = dealer.get(i).getSuit();
				String v = dealer.get(i).getValue();
				hand += v + " of " + s;
				hand += "\n";
				this.dealer.remove(i);
				this.dealer.trimToSize();
			}
		return hand;
  }
}
  
