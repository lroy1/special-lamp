//hw 

/*package client;
import service.Card;
import superclass.CardGame;
import subclass.Poker;
import subclass.Bridge;*/

import java.util.*;

public class PlayCardGames
{
 public static void main( String args [])
 {
  Poker poker = new Poker();
  Bridge bridge = new Bridge();
		
	//test to see if all cards have been added to Vector
			CardGame pokerGame = (CardGame)poker;
			CardGame bridgeGame = (CardGame)bridge;
			System.out.println("\nDeck of Cards:");
			System.out.println(pokerGame.toString());
		
			//testing shuffle method with poker class
			System.out.println("STARTING GAME OF POKER\nPoker Prelude:");
			System.out.println(poker.displayDescription());
			System.out.println("\nLETS PLAY!\nDealing 5 cards to first player:");
			System.out.println(poker.deal());
			
			
			System.out.println("==========================================================================================");
		
			//test to see if all cards have been added to vector after cards have been shuffled once
			System.out.println("\nDeck of Cards:");
			System.out.println(bridgeGame.toString());
			
			//testing shuffle method with bridge class
			System.out.println("STARTING GAME OF BRIDGE\nBridge Prelude:");
			System.out.println(bridge.displayDescription());
			System.out.println("\nLETS PLAY!\nDealing 13 cards to first player:");
			System.out.println(bridge.deal());
			
    }
}