package subclass;
import superclass.GeometricFigure2;
import interface1.SidedObject;

public class Square2 extends GeometricFigure2 //implements SidedObject
{
 
 public Square2(){
  super();
 }
 
 public Square2( double h, double w){
  super(h,w);
 }

 
 public double area(){
  double a= this.getHeight();
  double b= this.getWidth();
  double ret= a*b;
  return ret;
 }
 
 public int displaySides(){
  double h= this.getHeight();
  double w= this.getWidth();
  if(h==w){
   System.out.println("this geometric figure is of type Square");
   return 4;}
  else { System.out.println("this geometric figure is of type Triangle");
   return 3;}
 }
 
 public String toString(){
  return super.toString()+" area of figure is: "+this.area()+"the number of sides: "+this.displaySides();
 }
}