//HW6 

package client;
import superclass.Circle;
import subclass.Sphere;
import subclass.Cylinder;

public class CylinderSphereClient
{
 public static void main(String args [])
 {
  Cylinder cl1=new Cylinder( 28, 35);
  System.out.println(cl1.toString());
  
  Sphere s1= new Sphere(6);
  System.out.println(s1.toString());
  
  double cVol= cl1.volume();
  double sVol= s1.Volume();
  double div= cVol/sVol;
  System.out.println("the number of spheres that could fit in the cylinder are: "+div);
  
  Circle c1= new Circle(10);
  System.out.println(c1.toString());
  
  Circle c;
  c=cl1;
  System.out.println(c.toString());
  
  c=s1;
  System.out.println(c.toString());
  
  Circle cArray []= new Circle [3];
  Circle c2=new Circle(8);
  cArray[0]=c2;
  Sphere s2= new Sphere(12);
  cArray[1]=s2;
  Cylinder cl2= new Cylinder(7,11);
  cArray[2]=cl2;
  
  for(int i=0; i<3; i++){
   System.out.println(cArray[i].toString());
  }
 }
}