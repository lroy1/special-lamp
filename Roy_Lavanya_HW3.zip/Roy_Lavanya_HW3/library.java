package library.client.classes;
import java.util.Scanner;
import java.io.File;
import java.io.IOException;
import library.service.classes.BookGenre;
import library.service.classes.BookRecord;
class library{
	BookRecord []books; //array of objects
	int noRecords=0; //no of records; it is not the size of the array
	
	public void resize(int resizeFactor){//library to expand the array
		//initiatilize a new array with larger size and then copy the variables to
		int initSize = this.noRecords;
		BookRecord [] newArray = new BookRecord[initSize+resizeFactor];
		//copy the object over
		for(int i=0;i<this.books.length;++i){
			newArray[i]=this.books[i];
		}
		this.books=newArray;
		System.out.println("Resized the array from " + initSize + " to " + this.books.length);
		
	}
	public void searchByGenre(BookGenre genre){
		BookRecord [] sameGenre;
		int count=0;
		//loop through the book records and list the genre
		for(int i=0;i<this.noRecords;++i){
			if(this.books[i].getGenre()==genre){
		count++;}}
			System.out.println("num of records with same genre: "+count);
           sameGenre=new BookRecord[count];
      for(int k=0;k<this.noRecords; k++){
		if(this.books[k].getGenre()==genre){   
		   for(int j=0; j<count; j++){
			   sameGenre[j]=books[j];
		   }
		}
	  }
	  sameGenre=sortPages(sameGenre, count);
	  for(int y=0; y<count; y++){
		  System.out.println(sameGenre[y]);
	  }
	}
			   
	public boolean searchForDuplicate(BookRecord aRecord){
		//loop through the library and find duplicates
		//return true if duplicate found 
		//else return false
		if(this.noRecords==0) return false;
		for(int i=0;i<this.noRecords;++i){
			if(this.books[i].equals(aRecord))
				return true;
		}
		return false;
	}
	public void print(){//list the library
		for(int i=0;i<this.noRecords;++i){
			System.out.println(this.books[i].toString());
		}	
	}
	library(){
		this.books=new BookRecord[5];//intial size is 5		
	}
	public static void main(String []args){//instantiate the library
	//arg[0]: text file //arg[1]: resize factor
		int resizeFactor = Integer.parseInt(args[1]);
		library myLib = new library();
		//read the the files from text files
		String []authors;
		BookRecord aRecord;
		Scanner scan;
		String str;
		int numPage;
		String tag;
		
		try {
			File myFile=new File(args[0]);
            scan=new Scanner(myFile);//each line has the format title:genre:author-name-1,author-name-2..authorname-m
			while(scan.hasNextLine()){
				str=scan.nextLine();				
				String []tok=str.split(":");
				authors=tok[2].split(",");
				tag=tok[3];
				numPage= Integer.parseInt(tok[4]);
				
				aRecord = new BookRecord(tok[0],tok[1],authors, tag, numPage);
				
				//check for duplicate records
				if (!myLib.searchForDuplicate(aRecord)){
					//create a BookRecord object and load it on the array
					myLib.books[myLib.noRecords] = aRecord;
					myLib.noRecords++;
					//System.out.println("No of records: " + myLib.noRecords);
				}
				else{
					System.out.println("Found a duplicate");
					System.out.println(aRecord.toString());
				}
				//check if the array needs to resize
				if(myLib.books.length == myLib.noRecords){ //need to add additional space
					myLib.resize(resizeFactor);
				}
			}
			scan.close();
        }catch(IOException ioe){ 
			System.out.println("The file can not be read");
		}
		
		//User interactive part
		String option1, option2;
		scan = new Scanner(System.in);
		while(true){
			System.out.println("Select an option:");
			System.out.println("Type \"S\" to list books of a genre");
			System.out.println("Type \"P\" to print out all the book records");		
			System.out.println("type \"T\" to search for a record with a specific tag");
			System.out.println("Type \"Q\" to Quit");
			option1=scan.nextLine();
			
			switch (option1) {
				case "S":	System.out.println("Type a genre. The genres are:");
							for (BookGenre d : BookGenre.values()) {
									System.out.println(d);
							}
							option2=scan.nextLine(); //assume the user will type in a valid genre
							myLib.searchByGenre(BookGenre.valueOf(option2));
							
							break;
							 
				case "P":   //myLib.print();	 
				            BookRecord [] sorts= new BookRecord[myLib.books.length];
							sorts= myLib.sortString(myLib.books, myLib.noRecords);
							for (int g=0; g< myLib.books.length; g++){
							System.out.println(sorts[g].toString());}
							break;
				
				case "T" :  System.out.println("enter a tag value");
				            option2=scan.nextLine();
							myLib.searchTag(option2);
							break;
				
				case "Q":   System.out.println("Quitting program");
							System.exit(0);
							
				default:	System.out.println("Wrong option! Try again");
							break;
			
			}
			
		}
			 
	}
	
  public BookRecord [] sortString(BookRecord [] myArray, int noRecords1)
	{
		BookRecord temp;
		int i=0;
		boolean swap=true;
		while(swap){
			swap=false;
			i++;
			for(int j=0; j<noRecords1-i; j++)
			{
				if(myArray[j].getTag().compareTo(myArray[j+1].getTag())<0)
				{
					temp=myArray[j];
					myArray[j]=myArray[j+1];
					myArray[j+1]=temp;
					swap=true;
				}
			}
		}
		
		
	return myArray;
  }
	
 public BookRecord [] sortPages(BookRecord [] myArray1, int noOfRecord2)
 {
	 BookRecord temp;
	 int i=0;
	 boolean swap= true;
	 while(swap){
		 swap=false;
		 i++;
		 for(int j=0; j<noOfRecord2-i; j++)
		 {
			 if(myArray1[j].getPage()> myArray1[j+1].getPage())
			 {
				 temp=myArray1[j];
				 myArray1[j]=myArray1[j+1];
				 myArray1[j+1]=temp;
				 swap=true;
			 }
		 }
	 }
	 return myArray1;
 }
		
	 
 
 
 public void searchTag (String tag2)
 {
	 int low=0;
	 int high=books.length-1; //binary search
	 int mid;
	 
	 while(low <= high){
		 mid =(low+high)/2;
		 
		 if(books[mid].getTag().compareTo(tag2) <0){
			 low=mid+1;
		 } else if (books[mid].getTag().compareTo(tag2)>0){
			 high=mid-1;
		 } else if(books[mid].getTag().compareTo(tag2)==0){
			 if(books[mid].getTag().equals(tag2)){
			 System.out.println("tag found: "+ books[mid].toString());}
			 else { System.out.println("no result found!" );
			 }
	     }
	 }
 }
   
   
	
}