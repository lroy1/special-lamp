package subclasses;
import superclass.Record;

public class Magazines extends Record
{
 private int issue;
 private int volume;
 private String editor;
 
 public Magazines(){
  this.setIssue(0);
  this.setVolume(0);
  this.setEditor(" ");
  
 }
 
 public Magazines( int issue1, int volume1, String edit){
  this.setIssue(issue1);
  this.setVolume(volume1);
  this.setEditor(edit);
 }
 
 public Magazines (String title, String date,  int iss, int vol,String editor){
  super(title, date);
  this.setEditor(editor);
  this.setIssue(iss);
  this.setVolume(vol);
 }
 
 public int getIssue(){
  return this.issue;
 }
 
 public int getVolume(){
  return this.volume;
 }
 
 public String getEditor(){
 return this.editor;}
 
 
 public void setIssue( int iss1){
  this.issue=iss1;
 }
 
 public void setEditor( String author){
  this.editor=author;
 }
 
 public void setVolume(int vol1){
  this.volume=vol1;
 }
 
 public String toString(){
  return super.toString()+ " the issue no. is: "+getIssue()+" The volume no. is: "+getVolume()+" the name of editor is: "+getEditor();
 }
 
}