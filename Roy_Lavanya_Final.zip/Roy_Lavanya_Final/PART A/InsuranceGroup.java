// final 


package group;
import java.util.*;
import superclass.Insurance;
import subclass.LifeInsurance;
import subclass.HealthInsurance;

public class InsuranceGroup
{ 
 private String GroupID;
 private static int Counter=1000;
 private Vector <Insurance> vec;
 
 public InsuranceGroup(){
  this.GroupID="GR-"+Counter;
  Counter++;
  //vec.add(null);
 }
 
 public String getGroupID(){
  return this.GroupID;
 }
  
 public int AddPolicy(Insurance i){
  if(vec.size()<5){
   vec.add(i);
   return 1;
  }
  else if( this.averageAge() <45){
   vec.add(i);
   return 0;
  }
  else { System.out.println("conditions not met");
  return 0;}
 }
  
  
 public double averageAge(){
  int sum =0;
  for(int i=0; i<vec.size(); i++){
   sum += vec.elementAt(i).getAge();
  }
  double avg = (double) sum/vec.size();
  return avg;
 }
 
 public int total(){
  int sum1=0;
  for(int j=0; j<vec.size(); j++){
   sum1 += vec.elementAt(j).getMFee();
  }
  return sum1;
 }
 
 public String toString(){
  return "insurance group id: "+getGroupID()+" No. of policies: "+this.vec.size()+"average age of group: "+this.averageAge()+" total monthly fee: "+this.total();
 }
}