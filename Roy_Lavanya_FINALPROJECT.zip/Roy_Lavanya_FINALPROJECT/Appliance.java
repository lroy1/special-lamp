// project 

package superclass;

public class Appliance
{
 private String name;
 private int location;
 private int onWattage;
 private double probOn;
 private static int counter =0;
 
 public Appliance(){
  this.setName(" ");
  this.setLocation(0);
  this.setOnWattage(0);
  this.setProbOn(0.0);
  counter++;
 }
 
 public Appliance(String nAme, int loc, int oWatt, double prob){
  this.setName(nAme);
  this.setLocation(loc);
  this.setOnWattage(oWatt);
  this.setProbOn(prob);
  counter++;
 }
 
 public String getName(){
  return this.name;
 }
 
 public int getLocation(){
  return this.location;
 }
 
 public int getOnWattage(){
  return this.onWattage;
 }
 
 public double getProbOn(){
  return this.probOn;
 }
 
 public void setName(String name1){
  this.name=name1;
 }
 
 public void setLocation(int loc1){
  this.location=loc1;
 }
 
 public void setOnWattage(int watt){
  this.onWattage=watt;
 }
 
 public void setProbOn(double pOn){
  this.probOn=pOn;
 }
 
 public String toString(){
  return "Appliance name: "+getName()+" location: "+getLocation()+" On wattage "+getOnWattage()+"  probability of being on: "+getProbOn();
 }
 
}