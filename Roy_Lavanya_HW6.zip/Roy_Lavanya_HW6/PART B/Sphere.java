// HW 6

package subclass;
import superclass.Circle;

public class Sphere extends Circle 
{
 
 public Sphere(){
  super();
 }
 
 public Sphere( double radius){
  super(radius);
 }
 
 public Sphere(Circle c1){
  super(c1.getRadius());
 }
 
 public double Volume(){
  double r= this.getRadius();
  double pro= 4*3.14*r*r*r;
  double ret= pro/3;
  return ret;
 }
 
 public String toString(){
  return super.toString()+" the volume of sphere is: "+Volume();
 }
}