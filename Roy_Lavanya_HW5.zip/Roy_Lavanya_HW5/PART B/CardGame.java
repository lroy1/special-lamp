//hw 5 
import java.util.*;

//package superclass;
//import service.Card;

public abstract class CardGame
{
 private final int SUITS =4;
 private final int VALUES = 13;
 private final int DECK= 52;
 
 private Vector <Card> deck = new Vector(DECK);
 private int deal;
 
 public CardGame( int deals){
  this.deal=deals;
   
   for(int i=0; i<DECK; i++){
    String suit = null;
	String value= null;
	switch(i)
	{
	 case 1:
	  suit="clubs";
	  break;
	 case 2:
	  suit="diamonds";
	  break;
	 case 3:
	  suit="hearts";
	  break;
	 case 4:
	  suit="spades";
	  break;
	 default:
	  break;
	 }
	 for(int j=1; j<VALUES; j++){
	  if( j==1){
	   value="Ace";
	  }
	  else if (j>1 && j<=10){
	   value=Integer.toString(j);
	  }
	  else if (j ==11){
	   value="jack";
	  }
	  else if(j==12){
	   value="queen";
	  }
	  else if(j==13){
	   value="king";
	  }
	  
	  Card card= new Card( suit, value);
	  deck.add(card);
	 }
   }
  }
  
 public Vector <Card> getDeck(){
  return this.deck;
 }
 
 public void setDeck ( Vector <Card> deck1){
  this.deck = deck1;
 }
 
 public String toString (){
  String hand=" ";
  
  for(int a=0; a<VALUES ;a++){
   for(int b=0; b<DECK ; b++){
    hand += this.deck.elementAt(a).getValue() + " of "+ this.deck.elementAt(b).getSuit();
   }
  }
  return hand;
 }
 
 public void shuffle (Vector <Card> deck2, int size){
  System.out.println("shuffling");
  Random random = new Random();
  for(int z=0; z<1000; z++){
   int num = random.nextInt(size);
   Card temp= deck2.elementAt(num);
   deck2.remove(num);
   deck2.add(temp);
  }
 }
 
 public abstract String displayDescription();
 public abstract String deal();
}