//hw 5
import java.util.*;

/*package subclass;
import service.Card;
import superclass.CardGame;*/

public class Poker extends CardGame
{
 private static final int DEAL = 5;
 Vector <Card> dealer = super.getDeck();
 
 public Poker(){
  super(DEAL);
 }
 
 public String displayDescription(){
  return "According to Wikipedia, \"Poker is a family of gambling card games. All poker variants involve betting as an\n" +
							"intrinsic part of play, and determine the winner of each hand according to the combinations of players' cards,\n" +
							"at least some of which remain hidden until the end of the hand. Poker games vary in the number of cards dealt, \n" +
							"the number of shared or \"community\" cards, the number of cards that remain hidden, and the betting procedures.\"";
	}
	
  public String deal(){
   String hand;
   int size= this.dealer.size();
   super.shuffle(this.dealer, this.dealer.size());
			hand = "";
			int start = this.dealer.size() - 1;
			int end = start - DEALS;
			//removes cards from deck as they are given to players
			for (int i = start; i > end; i--)
			{
				String s = dealer.get(i).getSuit();
				String v = dealer.get(i).getValue();
				hand += v + " of " + s;
				hand += "\n";
				this.dealer.remove(i);
				this.dealer.trimToSize();
			}
	return hand;
  }
}
   