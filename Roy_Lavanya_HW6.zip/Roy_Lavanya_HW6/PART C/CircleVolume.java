//HW 6

package superclass;

public abstract class CircleVolume
{
 private double radius;
 
 public CircleVolume(){
  this.setRadius(0.0);
 }
 
 public CircleVolume(double r){
  this.setRadius(r);
 }
 
 public CircleVolume(CircleVolume cv){
 }
 
 public double getRadius(){
  return this.radius;
 }
 
 public void setRadius(double rad){
  this.radius=rad;
 }
 
 public double circumference(){
  double r= this.getRadius();
  double ret= 2*3.14*r;
  return r;
 }
 
 public double area(){
  double r= this.getRadius();
  double ret= 3.14*r*r;
  return ret;
 }
 
 public String toString(){
  return "this is an object with radius: "+this.getRadius()+" the area is: "+area()+" the circumference is: "+circumference();
 }
 
 public abstract double volume();
 
}
 
 