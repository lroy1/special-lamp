package subclasses.sub;
import superclass.Record;
import subclasses.Books;

public class HardCopy extends Books
{
 private int edition;
 
 public HardCopy(){
  this.setEdition(0);
 }
 
 public HardCopy( int edi){
  this.setEdition(edi);
 }
 
 public HardCopy( String title, String date, String author, int edit){
  super(title, date, author);
  this.setEdition(edit);
 }
 
 public int getEdition(){
  return this.edition;
 }
 
 public void setEdition( int edit2){
  this.edition=edit2;
 }
 
 public String toString(){
  return super.toString()+" the edition is: "+getEdition();
 }
 
}

