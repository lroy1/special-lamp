//part a midterm quad
package Midterm.Service;
import Midterm.Service.House;
import java.util.*;


public class Quad
{
 private Vector houses;
 private House h1=new House();
 
 public Quad()
 {
  houses=new Vector(12);
 }
 
 public Quad (int sizeLimit)
 {
  houses=new Vector(sizeLimit);
 }
 
 public int getSize()
 {
  return houses.size();
 }
 
 public boolean AddHouse(House h2)
 {
  houses.addElement(h2);
  return true;
 }
 
 public String toString()
 {
  return "the current size of the collection is: "+this.getSize();
 }
 
}