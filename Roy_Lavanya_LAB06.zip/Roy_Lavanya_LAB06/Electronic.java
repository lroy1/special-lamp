package subclasses.sub;
import superclass.Record;
import subclasses.Magazines;

public class Electronic extends Magazines
{
 private String url; 
 
 public Electronic(){
  this.setUrl(" ");
 }
 
 public Electronic( String url1){
  this.setUrl(url1);
 }
 
 public Electronic( String title, String date, String author, int issue, int vol, String url2){
  super(title, date, issue, vol,  author);
  this.setUrl(url2);
 }
 
 public String getUrl(){
  return this.url;
 }
 
 public void setUrl( String url3){
  this.url=url3;
 }
 
 public String toString(){
  return super.toString()+" the url of this magazine is: "+getUrl();
 }
}