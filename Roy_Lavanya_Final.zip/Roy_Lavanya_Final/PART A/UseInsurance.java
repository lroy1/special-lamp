import java.util.*;
import java.io.File;
import java.io.IOException;

//package client1;
import superclass.Insurance;
import subclass.HealthInsurance;
import subclass.LifeInsurance;
import group.InsuranceGroup;

class UseInsurance{
	
	Vector <InsuranceGroup> igs = new Vector (10);
	
	
	public static void main(String []args){		
	 UseInsurance ui = new UseInsurance();
	//arg[0]: text file  containing the policy information		
	   int counter=0;
	   int count=1000;
		Scanner scan;
		String str;
		
		try {
			File myFile=new File("insurance.txt");
            scan=new Scanner(myFile);//each line has the format 
			//name;age;policy-type{Health or Life}
			while(scan.hasNextLine()){
				str=scan.nextLine();			
				String []tok=str.split(";");
				String name=tok[0];//name of the policy holder
				//System.out.println(name);
				int age = Integer.parseInt(tok[1]);//age of the policy holder
				String type = tok[2];//type of the insurance values are "Health" or "Life"
			
				if(type.equals("Health")){
										//this is a Health insurance policy	
                   HealthInsurance h = new HealthInsurance(count, name, age, type);
                   int confirm= ui.igs.elementAt(counter).AddPolicy(h);
				   if(confirm ==1){
				     System.out.println("done");
			       }
				   else if(confirm ==0){
					   int again = ui.igs.elementAt(counter+1).AddPolicy(h);
				   }
				  
				  count++;
				}
				  
				else {
					//this is a Life insurance policy
				 
				   LifeInsurance l = new LifeInsurance(count, name, age, type);
				   int confirm1= ui.igs.elementAt(counter).AddPolicy(l);
				   if(confirm1 ==1){
				     System.out.println("done");
			       }
				   else if(confirm1 ==0){
					   int again = ui.igs.elementAt(counter+1).AddPolicy(l);
				   }
				  
					count++;		
										
				}}counter++;
			//scan.close();
				}catch(IOException ioe){ 
			System.out.println("The file can not be read");
		}
		
		for(int x=0; x<ui.igs.size(); x++){
			System.out.println(ui.igs.elementAt(x).toString());
			System.out.println("done");
		}
		
		
	}
}
		