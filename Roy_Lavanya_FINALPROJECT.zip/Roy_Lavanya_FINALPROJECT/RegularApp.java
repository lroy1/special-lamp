//Project

package subclass;
import superclass.Appliance;

public class RegularApp extends Appliance
{
 
 public RegularApp(){
  super();
 }
 
 public RegularApp(String name, int loc, int onwatt, double prob){
  super(name, loc, onwatt, prob);
 }
 
 public RegularApp(Appliance app){
  super(app.getName(), app.getLocation(), app.getOnWattage(), app.getProbOn());
 }
 
 public String toString(){
  return super.toString()+" this is appliance of type: regular";
 }
}