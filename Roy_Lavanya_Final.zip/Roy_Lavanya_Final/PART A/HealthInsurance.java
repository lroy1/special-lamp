// final 

package subclass;
import superclass.Insurance;

public class HealthInsurance extends Insurance
{
 public HealthInsurance(){
  super();
 }
 
 public HealthInsurance(int id, String name1, int age1, String type1){
  super(id, name1, age1, type1);
 }
 
 public HealthInsurance( Insurance i1){
  super(i1.getPolicyID(), i1.getName(), i1.getAge(), i1.getType());
 }
 
 public void setCost(){
  this.setMFee(180);
 }
}
