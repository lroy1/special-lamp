//hw 5

package subclass;
import superclass.Loan;
import interface1.LoanConstants;

public class BusinessLoan extends Loan
{
 
 private final int addInterest =1;
 
 public BusinessLoan(){
  super();
  super.setRate(0+addInterest);
 }
 
 public BusinessLoan( String name, int term, double amt, double passedInterest){
  super(name, term, amt);
  super.setRate(passedInterest+addInterest) ;
 }
 
 public double paymentDue(){
	 double rate = super.getRate();
	 double amt= super.getAmount();
     double product = rate*amt;
     double ret = amt+ product;
  return ret;	 
 }

 public String toString(){
	 return super.toString()+ "amount due at end of term: "+paymentDue();
 }
}