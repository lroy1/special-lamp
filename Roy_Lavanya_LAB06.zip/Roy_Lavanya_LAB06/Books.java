
package subclasses;
import superclass.Record;

public class Books extends Record
{
 private String author;
 
 public Books(){
  super();
  this.setAuthor(" ");
  }
 
 public Books( String title, String date, String author){
  super (title, date);
  this.setAuthor(author);
 }
 
 public String getAuthor(){
	 return this.author;
 }
 
 public void setAuthor( String aut){
	 this.author= aut;
 }
 
 public String toString(){
  return super.toString();
 }
}

