package subclasses.sub;
import superclass.Record;
import subclasses.Books;

public class Ebooks extends Books
{
 private String url;
 
 public Ebooks(){
  this.setUrl(" ");
 }
 
 public Ebooks( String url1){
  this.setUrl(url1);
 }
 
 public Ebooks( String title, String date, String author, String url2){
  super(title, date, author);
  this.setUrl(url2);
 }
 
 public String getUrl(){
  return this.url;
 }
 
 public void setUrl( String url3){
  this.url=url3;
 }
 
 public String toString(){
  return super.toString()+" the url of this books is: "+getUrl();
 }
}