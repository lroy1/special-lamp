// assignment 1

import java.util.Random;

public class Spinner1
{
 
 private int arrowPos;
 
 public Spinner1()
 {
  this.arrowPos=0; // default stating postion
 }
 
 public Spinner1( int initial)
 {
  this.arrowPos=initial;
 }
  
 public boolean setArrow( int k)
 {
  this.arrowPos= k;
  return true;
 }
 
 public int getArrow()
 {
  return arrowPos;
 }
 
 public int spin(int random)
 {
  int max=random;
  int min=0;
  int rndVal = 0;
  int range = max-min+1;
  
  if (arrowPos >= min && arrowPos <= max) {
	  arrowPos = rndVal;
  } else {
	  arrowPos = 0;
  }
  // rndVal=(int)(Math.random()*(range)+min);
  rndVal=(int)(Math.random() * (range));
  
  System.out.println( "random value is " +rndVal);
  
  arrowPos=rndVal;
  return arrowPos;
 }
 
  public String toString()
  {
  return "initial position is" +arrowPos;}
 
  
  public boolean equals (Spinner1 one)
  {
   if(one==this)
   return true;
   else 
   return false;
  }
} 
  