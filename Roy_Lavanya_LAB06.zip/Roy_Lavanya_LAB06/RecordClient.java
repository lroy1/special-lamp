package client;
import superclass.Record;
import subclasses.Magazines;
import subclasses.Newspapers;
import subclasses.sub.Ebooks;
import subclasses.sub.HardCopy;
import subclasses.sub.Electronic;
import subclasses.sub.Paperback;

import java.util.*;



public class RecordClient
{
 public static void main( String args [])
 {
  HardCopy book1 = new HardCopy();
  Newspapers news = new Newspapers();
  Electronic magazine = new Electronic();
  
  System.out.println("printing obj 1");
  System.out.println( book1.toString());
  System.out.println("printing obj 2");
  System.out.println( news.toString());
  System.out.println("printing obj 3");
  System.out.println( magazine.toString());
  
  }
}

