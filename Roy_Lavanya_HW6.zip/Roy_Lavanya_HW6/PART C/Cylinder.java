// HW 6

package subclass;
import superclass.CircleVolume;

public class Cylinder extends CircleVolume
{
 private float height;
 
 public Cylinder(){
  super();
  height= 0.0f;
  height= 0.0f;
 }
 
 public Cylinder(double r, float h){
  super(r);
  this.setHeight(h);
 }
 
 public Cylinder(CircleVolume cv, float hgt){
  super(cv.getRadius());
  this.setHeight(hgt);
 }
 
 public float getHeight(){
  return this.height;
 }
 
 public void setHeight(float h){
  this.height=h;
 }
 
 public double volume(){
  float h= this.getHeight();
  double area= this.area();
  double ret= area*h;
  System.out.println("formula is: area*h");
  return ret;
 }
 
 public String toString(){
  return super.toString()+" the height of cylinder is: "+this.getHeight()+" the volume of cylinder is: "+volume();
 }
}