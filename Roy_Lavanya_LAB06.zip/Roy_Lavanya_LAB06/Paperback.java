package subclasses.sub;
import superclass.Record;
import subclasses.Magazines;

public class Paperback extends Magazines
{
 private String edition;
 
 public Paperback(){
  this.setEdition(" ");
 }
 
 public Paperback( String edi){
  this.setEdition(edi);
 }
 
 public Paperback( String title, String date, String author, int issue, int vol, String edit){
  super(title, date, issue, vol, author);
  this.setEdition(edit);
 }
 
 public String getEdition(){
  return this.edition;
 }
 
 public void setEdition( String edit2){
  this.edition=edit2;
 }
 
 public String toString(){
  return super.toString()+" the edition is: "+getEdition();
 }
 
}


 
 