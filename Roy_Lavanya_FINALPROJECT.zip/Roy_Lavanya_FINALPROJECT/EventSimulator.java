package client;
import superclass.Appliance;
import subclass.RegularApp;
import subclass.SmartApp;


import java.util.*;
import java.io.*;



public class EventSimulator {
	
	
	Vector <Appliance> apps = new Vector (10);
	Vector <RegularApp> rApps = new Vector (10);
	Vector <SmartApp> sApps = new Vector (10);
	
	
	
	public static void main(String[] args)throws IOException {
		
		EventSimulator es = new EventSimulator();
		int loc=0;
	String name=" ";
	int onWatt=0;
	double probOn=0.0;
	boolean type=true;
	int offWatt=0;
	double smartRed=0;
		
		File ifile = new File("output.txt");
		Scanner scan = new Scanner (ifile);
		String read =" ";
		
		while(scan.hasNextLine()){
			read= scan.nextLine();
			String tok [] = read.split(",");
			loc=Integer.parseInt(tok[0]);
			name= tok[1];
			onWatt=Integer.parseInt(tok[2]);
			probOn=Double.parseDouble(tok[3]);
			type=Boolean.parseBoolean(tok[4]);
			smartRed=Double.parseDouble(tok[5]);
			
			if(type==true){
				SmartApp sa= new SmartApp(name, loc, onWatt, probOn, smartRed);
			    es.apps.add(sa);
				es.sApps.add(sa);
			}
			else if (type== false){
				RegularApp ra = new RegularApp(name, loc, onWatt, probOn);
				es.apps.add(ra);
				es.rApps.add(ra);
			}
			
		}
		
		Scanner scan1 = new Scanner (System.in);
		boolean ques = true;
		String ans=" ";
		String search=" ";
		int search1 =0;
		
		while(ques){
			System.out.println("Do you want to add an appliance? Y/N");
			ans= scan1.next();
			
			if( ans.equalsIgnoreCase("y")){
				System.out.println("What is the appliance name?");
				name=scan.next();
				System.out.print("What is the appliance location? ");
				loc = scan.nextInt();
				System.out.print("What is the appliance type? ");
				type = Boolean.parseBoolean(scan.next());
				System.out.print("What is the appliance on wattage? ");
				onWatt = scan.nextInt();
				System.out.print("What is the appliance on probability? ");
				probOn = scan.nextFloat();
		        
				if (type == true){
				SmartApp sa= new SmartApp(name, loc, onWatt, probOn, smartRed);
			    es.apps.add(sa);
				es.sApps.add(sa);
			   }
			    else if (type== false){
				RegularApp ra = new RegularApp(name, loc, onWatt, probOn);
				es.apps.add(ra);
				es.rApps.add(ra);
			   }
			}
			else if (ans.equalsIgnoreCase("N")){ System.out.println("ok");}
			
			System.out.print("Do you want to see all the appliances for a type? Y/N ");
			ans= scan1.next();
			if (ans.equalsIgnoreCase("y"))
			{
				System.out.print("Enter which type: S for smart, R for regular");
				String userType = scan1.next();
				es.searchType(userType, es.sApps, es.rApps);
			}
			
			
			System.out.println("do you want to delete an appliance? Y/N");
			ans = scan1.next();
			
			   if(ans.equalsIgnoreCase("Y")){
				System.out.println("enter name of appliance");
				search = scan1.next();
				System.out.println("enter the location");
				search1 = scan1.nextInt();
				System.out.println("enter type of appliance: s for smart and R for regular");
				String type5 = scan1.next();
				if(type5.equalsIgnoreCase("s")){
					es.deleteSApp(search, search1, es.sApps);}
				else if(type5.equalsIgnoreCase("r")){
				    es.deleteRApp(search, search1, es.rApps);
				}
			 }
			   else if (ans.equalsIgnoreCase("N")){
				   System.out.println("okay");
				   ques=false;
			   }
		  }
		
		final int ARRIVAL_MEAN=5;
		int simulationLength=0, minute=0, nextArrivalTime, callCount=0; 
		Scanner input = new Scanner(System.in);
	
		while (simulationLength<=0)	{
			System.out.print("How many minutes long is the simulation? "); 

			while (!input.hasNextInt()) {
				input.next();
				System.out.print("Please enter an integer: ");
			}
			simulationLength = input.nextInt();
		}

		nextArrivalTime = minute + getRandInt('E', ARRIVAL_MEAN, 0);
		
		while(minute<=simulationLength) {
			while ((minute == nextArrivalTime) && (minute<=simulationLength)) {
				callCount++;
				System.out.println("Minute:"+minute+" Event#"+callCount);
				nextArrivalTime=minute+getRandInt('E', ARRIVAL_MEAN, 0);
			}
			minute++;
		} 
		System.out.println("Number of events = " + callCount);
		
		System.out.println("What is the max Wattage of the grid?");
		int maxWatt = scan1.nextInt();
		
		Vector <Appliance> apps1 = new Vector(es.apps.size());
		for(int x=0; x<es.apps.size(); x++){
			apps1.add(es.apps.elementAt(x));
		}
			Vector <SmartApp> sApps1 = new Vector(es.sApps.size());
		for(int d=0; d<es.sApps.size(); d++){
			sApps1.add(es.sApps.elementAt(d));
		}
			Vector <RegularApp> rApps1 = new Vector(es.rApps.size());
		for(int e=0; e<es.rApps.size(); e++){
			rApps1.add(es.rApps.elementAt(e));
		}
		
		
	for(int w=1; w<=callCount; w++){
		es.powerSimulation(maxWatt, apps1, sApps1, rApps1);
		
	}
}

	public static int getRandInt(char type, int x, int y) {
		int num;
		switch (type) { 
		case 'U': case 'u':		// Uniform Distribution
			num = (int)(x + (Math.random()*(y+1-x))); 
			break;
		case 'E': case 'e':		// Exponential Distribution
			num = (int)(-1*x*Math.log(Math.random()));  
			break;	
		case 'N': case 'n':		// Normal Distribution
			num = (int)( x +
                (y * Math.cos(2 * Math.PI * Math.random()) *
                Math.sqrt(-2 * Math.log(Math.random()))));
			break;			
		default:				// Uniform Distribution
			num = (int)(x + (Math.random()*(y+1-x))); 
		}
		return num;
	}
	
	public void searchType(String type, Vector <SmartApp> s, Vector <RegularApp> r){
		 if(type.equalsIgnoreCase("S")){
			 for(int i=0; i<s.size(); i++){
				 System.out.println(s.elementAt(i).toString());
			 }
		 }
	    else if(type.equalsIgnoreCase("R")){
			for(int j=0; j<r.size(); j++){
				System.out.println(r.elementAt(j).toString());
			}
		}
	}
   
   public void deleteSApp( String name2, int loc2, Vector <SmartApp> vec){
	   for(int z=0; z<vec.size(); z++){
		   if(vec.elementAt(z).getName()== name2 && vec.elementAt(z).getLocation()==loc2){
			   vec.remove(z);
		   }
	   }
   }
   public void deleteRApp( String name2, int loc2, Vector <RegularApp> vec){
	   for(int z=0; z<vec.size(); z++){
		   if(vec.elementAt(z).getName()== name2 && vec.elementAt(z).getLocation()==loc2){
			   vec.remove(z);
		   }
	   }
   }
   
   
   public void powerSimulation(int wattage, Vector <Appliance> vec, Vector <SmartApp> vec1, Vector <RegularApp> vec2){
	  //to find current wattage of appliances. 
	   
	   int currentUsage =0;
	   boolean on = probablityOn(vec);
	   if(on == true){
		  for(int u=0; u<vec.size(); u++){
		     currentUsage += vec.elementAt(u).getOnWattage();
			  System.out.println("current usage"+ currentUsage);
		 }
		
	   }
	   
      int f=0;
	   boolean smartTurnedLow= false;
	   boolean done = true;
	  while(done){ 
	   int loc = vec.elementAt(f).getLocation();
	   int locApps = this.appsInLoc(loc, vec);
	   int maxwatt = this.threshold(currentUsage, locApps)*this.getNumOfLocs();
	    
	  if(!smartTurnedLow)
	   {
		  Vector <SmartApp> nvec1= this.sortSmart(vec1);
		  this.smartLow(nvec1);
		  smartTurnedLow = true;
	   }
	   if(currentUsage <= wattage){ System.out.println("total wattage below max");
	   done = false;}
	   else
	   {
		   this.sortOnWatts();
		   this.brownOut(currentUsage, locApps, loc);
		   if(currentUsage < wattage){
			   System.out.println("total wattage below max");
			   done = false;
		   }
	   }
	  }
   }
   
   public void brownOut(int totalWatts, int locApps, int loc)
	{
		//System.out.println("This location has been browned out: loc " + loc);
		int maxWattsInLoc = this.threshold(totalWatts, locApps);
		int wattsPerLoc = totalWatts/this.getNumOfLocs();
		int i = 0;
		boolean firstLoc = true;
		while (this.apps.elementAt(i).getLocation() == loc)
		{
			if (firstLoc)
			{
				System.out.println("browning out loc " + loc);
				firstLoc = false;
			}
			this.apps.elementAt(i).setOnWattage(0);
			i++;
		}
	}
	public Vector <SmartApp> sortSmart(Vector <SmartApp> vc){
		boolean swapped = true;
		SmartApp temp;
		while (swapped)
		{
			swapped = false;
			for (int j = 0; j < vc.size() - 1; j++)
			{
				if (vc.elementAt(j).getOnWattage() < vc.elementAt(j + 1).getOnWattage())
				{
					temp = vc.elementAt(j);
					vc.add(temp);
					vc.remove(j);
					swapped = true;
				}
			}
		}
		return vc;
	}
	
	
	public int appsInLoc(int loc, Vector <Appliance> apps3)
	{
		int locApps = 0;
		for (int r=0; r<apps3.size(); r++)
		{
			if (apps3.elementAt(r).getLocation() == loc)
			{
				locApps++;
			}
		}
		return locApps;
	}
	 
    public void smartLow(Vector <SmartApp> v2)
	{
		for (int i = 0; i < v2.size(); i++)
		{
		  v2.elementAt(i).setOnWattage(v2.elementAt(i).FindLowWatt());
		}
		System.out.println("Turning smart appliances to low power");
	}  
	
	public boolean probablityOn(Vector <Appliance> v)
	{
		double rand = 0.5;
		boolean ret=false;
	   for(int h=0; h < v.size(); h++){
		 if (rand <= v.elementAt(h).getProbOn())
		{
			ret = true;
		}
		else
		{
			ret= false;
		}
	  }
	  return ret;
	}
	
	 public int threshold(int totalPower, int locApps)
    {
        int perApp = totalPower/apps.size();
        int powerInRoom = perApp * locApps;
        return powerInRoom;
    }

	public int getNumOfLocs(){
		int num=0;
		for(int t=0; t<apps.size()-1; t++){
			if(apps.elementAt(t).getLocation() != apps.elementAt(t+1).getLocation()){
				num++;
			}
			//else {System.out.println("problem here!");}
		}
	return num;}
	
	
	public void sortOnWatts()
	{
		boolean swapped = true;
		Appliance temp;
		while (swapped)
		{
			swapped = false;
			for (int j = 0; j < apps.size() - 1; j++)
			{
				if (apps.elementAt(j).getOnWattage() < apps.elementAt(j + 1).getOnWattage())
				{
					temp = apps.elementAt(j);
					apps.add(temp);
					apps.remove(j);
					swapped = true;
				}
			}
		}
	}
	
	
}