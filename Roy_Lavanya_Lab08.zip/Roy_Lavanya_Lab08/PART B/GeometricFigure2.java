//lab 08
package superclass;
import interface1.SidedObject;

public abstract class GeometricFigure2 implements SidedObject
{
 private double height;
 private double width;
 
 public GeometricFigure2(){
  this.setHeight(0);
  this.setWidth(0);
 }
 
 public GeometricFigure2( double h1, double w1){
  this.setHeight(h1);
  this.setWidth(w1);
 }
 
 
 public double getHeight(){
  return this.height;
 }
 
 public double getWidth(){
  return this.width;
 }
 
 
 public void setHeight(double h){
  this.height=h;
 }
 
 public void setWidth(double w){
  this.width=w;
 }
 
 public abstract double area();
  
  public String toString(){
   return "this is a geometric figure with height: "+getHeight()+" and width: "+getWidth();
  }
}
 