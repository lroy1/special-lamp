// FINAL 

package superclass;

public abstract class Insurance
{
 private int PolicyID;
 private String name;
 private int age;
 private String type;
 private int mFee;
 
 public Insurance(){
  this.setPolicyID(0);
  this.setName(" ");
  this.setAge(0);
  this.setType(" ");
  this.setMFee(0);
 }
 
 public Insurance(int id, String name1, int age1, String type1){
  this.setAge(age1);
  //this.setMFee(m);
  this.setName(name1);
  this.setPolicyID(id);
  this.setType(type1);
 }
 
 public int getPolicyID(){
  return this.PolicyID;
 }
 
 public String getName(){
  return this.name;
 }
 
 public int getAge(){
  return this.age;
 }
 
 public int getMFee(){
  return this.mFee;
 }
 
 public String getType(){
  return this.type;
 }
 
 public void setAge( int a){
  this.age=a;
 }
 
 public void setMFee(int c){
  this.mFee=c;
 }
 
 public void setName(String s){
  this.name= s;
 }
 
 public void setPolicyID(int id1){
  this.PolicyID=id1;
 }
 
 public void setType(String t){
  this.type=t;
 }
 
 public abstract void setCost();
 
// public String toString(){
  //return "Insurance id: "+getPolicyID()+"  Name of policy holder: "+getName()+" age of policy holder: "+getAge()+" 
}
