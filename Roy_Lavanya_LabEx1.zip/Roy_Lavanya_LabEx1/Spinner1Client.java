// assignment 1

import java.util.Random;
import java.util.Scanner;

public class Spinner1Client
{
 public static void main(String args [])
 {
  
  Spinner1 d1= new Spinner1();
  Spinner1 d2= new Spinner1(5);
  
  String for1= d1.toString();
  System.out.println(for1);
  String for2= d2.toString();
  System.out.println(for2);
  
  int a = d1.getArrow();
  int b = d2.getArrow();
  int c = a+b;
  System.out.println(c);
  
  int sum = d1.getArrow() + d2.getArrow(); 
  System.out.println("Sum: " + sum);
  boolean last= d1.equals(d2);
  System.out.println("are these two spinners in the same position?" + last);
  
  System.out.println("enter an integer");
  Scanner scan=new Scanner(System.in);
  int k= scan.nextInt();
  int l=d1.spin(k);
  int m=d2.spin(k);
  boolean last2=d1.equals(d2);
  System.out.println("are their new psoitions same?" + last2);
  int n=l+m;
  System.out.println("new sum of positions "+n);
 }
}